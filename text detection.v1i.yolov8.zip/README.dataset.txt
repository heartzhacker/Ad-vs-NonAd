# text detection > 2022-05-17 5:07pm
https://universe.roboflow.com/akshithak-0pa4q/text-detection-qj5wx

Provided by a Roboflow user
License: CC BY 4.0

